if minecraft or error422 is not working
download java https://www.java.com/download/ie_manual.jsp